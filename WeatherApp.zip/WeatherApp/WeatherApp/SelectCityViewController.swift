//
//  SelectCityViewController.swift
//  WeatherApp
//
//  Created by Ulan Kamai on 29.07.2021.
//

import UIKit


protocol SelectCityProtocol: NSObjectProtocol {
    func getCity (name: String)
    
}

class SelectCityViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var getButton: UIButton!
    weak var delegate : SelectCityProtocol?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        getButton.layer.cornerRadius = 4
        getButton.layer.masksToBounds = false
    }
    

    @IBAction func getButtonPressed(_ sender: Any) {
        if let name = textField.text {
        delegate?.getCity (name: name)
        }
    }
    
}

