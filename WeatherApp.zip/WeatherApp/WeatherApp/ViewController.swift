//
//  ViewController.swift
//  WeatherApp
//
//  Created by Ulan Kamai on 29.07.2021.
//

import UIKit
import Alamofire
import CoreLocation

class ViewController: UIViewController {

    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var weatherState: UIImageView!
    @IBOutlet weak var tempLabel: UILabel!
    
    private let API_KEY: String = "9f256173c5c4aa573c179e730530c662"
    private let URL: String = "https://api.openweathermap.org/data/2.5/weather"
    private let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation ()

    }

    @IBAction func switchTempType(_ sender: Any) {
    }
    @IBAction func changeCityButtonPressed(_ sender: Any) {
    }
    
}
 
extension ViewController {
    
    
    override func prepare (for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "goToSelectCity"{
        if let vc = segue.destination as?  SelectCityViewController {
            vc.delegate = self
    
        }
        
    }
    
   }
    
    private func getWeatherCondition( params:[String: Any]? = nil){
        AF.request(URL, method: .get, parameters: params).responseJSON {response in switch response.result {
        case .success:
            if let responseData = response.data{
                print(responseData)
    
            do {
            let json = try JSONDecoder().decode(WeatherModel.self, from:responseData)
            self.tempLabel.text = "\(json.main.temp) "
                self.cityNameLabel.text = json.name
                self.weatherState.image = UIImage(named: self.updateWeatherIcon(condition: json.weather.first?.id ?? 905))
                
            } catch {
                print (error)
            }
            
        }
            
        case .failure (let error):
            print (error)
           }
        }
    }
    
    
    func updateWeatherIcon(condition: Int) -> String {
        switch (condition) {
        case 0...300 :
            return "tstorm1"
        case 301...500 :
            return "light_rain"
        case 501...600 :
            return "shower3"
        case 601...700 :
            return "snow4"
        case 701...771 :
            return "fog"
        case 772...799 :
            return "tstorm3"
        case 800 :
            return "sunny"
        case 801...804 :
            return "cloudy2"
        case 900...903, 905...1000 :
            return "tstorm3"
        case 903 :
            return "snow5"
        case 904 :
            return "sunny"
        default :
            return "dunno"
            
        }
    }
    
    
}

extension ViewController: CLLocationManagerDelegate  {
    
    func locationManager (_ manager: CLLocationManager, didFailWithError error: Error)
    {print ("Core Location failed to located")
        cityNameLabel.text = "Location Unavailable"}
    
    func locationManager (_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    let location = locations[locations.count - 1]
    if location.horizontalAccuracy > 0 {
    locationManager.stopUpdatingLocation ()
    print("location: \(location)")
    let params: [String: Any] = ["lat": location.coordinate.latitude, "lon": location.coordinate.longitude, "appid": API_KEY, "units": "metric"]
        
        getWeatherCondition(params: params)
    }
}
    }

extension ViewController: SelectCityProtocol{
    func getCity(name: String){
        getWeatherCondition(params: ["q": name , "appid": API_KEY, "units": "metric"])
    }
    
    }
