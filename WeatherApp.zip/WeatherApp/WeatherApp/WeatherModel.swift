//
//  WeatherModel.swift
//  WeatherApp
//
//  Created by Ulan Kamai on 29.07.2021.
//

import Foundation

struct WeatherModel: Decodable {
    let weather: [Weather]
    let main: Main
    let name: String
    
    struct Weather: Decodable {
        let id: Int
    }
    
        struct Main: Decodable {
            let temp: Double
        }
    
}
